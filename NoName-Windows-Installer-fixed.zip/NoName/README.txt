No Name — desktop app
WINDOWS: double-click Install-Windows.bat  (adds Desktop + Start menu shortcut)
MAC:     right-click Install-Mac.command > Open  (installs to Applications)
Needs internet once (downloads the ~110 MB app runtime from GitHub). Works offline afterwards.

v101 — Export engine & Performance panel
  * Install-Windows.bat now also downloads FFmpeg once (about 200 MB, kept for later re-installs).
    With it, Export saves a real MP4 (H.264) using your NVIDIA / AMD / Intel GPU encoder, or the CPU.
  * Ctrl+Shift+P shows a live Performance panel (fps, frame time, whether your GPU is really used).

v102: removed "Cutout -> Layer" / "Hit & Fling" toolbar buttons. Cutout tool now works on selected overlay clips (video/image): select overlay, press Cutout > Cutout. Better edges (sharper mask, stray-blob removal, hole fill, temporal smoothing).

v103: tutorial workflow "Masking cut-out": Freeze = one tap (3 s) -> Overlay (with a clip selected) moves it onto an overlay layer -> Mask (overlay) = circle/ellipse/rect/rounded/heart/star/band, invert, feather, size, X/Y, rotate, keyframes with Linear/Ease in/Ease out/Smooth. CapCut-style white clip selection, grip handles, speed/mute/duration chips.

v104: Mask shapes Horizontal + Mirror (like CapCut); effects Wide Angle + Color Glitch 2; AI assistant command "set all clips to N seconds"; CapCut transition slot between clips (white rounded square, cyan when set); CapCut cyan accent for Export / Import / primary buttons.

v105: freeze/image overlay layers can be stretched freely (drag the right edge; double-click the right edge = extend to the end of the timeline); Chroma Key panel: quick Green/Blue/White/Black + Pick-from-preview eyedropper, CapCut naming (Intensity, Feather edge).

v106
- Overlay clip name now stays inside its block (ellipsis, short CapCut-style label, e.g. "Freeze · name").
- 20 new effects: Dream Glow, Soft Focus, Anamorphic, Sunset, Moonlight, Prism, Spotlight 2, RGB Strobe, CRT TV, Dust & Scratch, Pencil Sketch, Cinema Bars, Matte Fade, Pop Art, Data Mosh, Double Vision, Echo Trail, Edge Blur, Frosted Glass, Blur Pulse.
- 10 new transitions: Curtain, Cube, Page Flip, RGB Split, Stripes, Pixel Dissolve, Whip Pan, Ripple, Light Leak, Stack Slide.

v107
- FIX: Overlay button no longer moves the selected main-track clip onto an overlay layer. It only opens "add image / video overlay". Only a Freeze result (the held frame) is lifted onto its own layer when you press Overlay right after Freeze.

v108
- FIX: Rotate / Flip / Mirror did nothing visible while the Crop box was open (and a rotated clip "snapped back" on Crop). They now close the crop box first; Crop on a rotated clip explains why the preview shows the original angle.
- FIX: the floating Keyframe/Curve/Lock/Duplicate/Delete bar sat on the row above a selected text/overlay and swallowed clicks meant for the main clip (clicking it could duplicate the text). It is now docked above the tracks.
- NEW: text, stickers and overlays work on an EMPTY project (black canvas) - plays, scrubs and exports. A media overlay with a blend mode (e.g. Multiply) is drawn above text, so white text + video overlay = video visible only inside the letters (text-window reveal).
- UI: one standard design for all sub-panels (header bar, sections, buttons, inputs, sliders, cyan Apply footer); long button labels wrap instead of being cut ("Duplicate Overlay", "In = Playhead"); duplicate panel titles removed.

v109
- Overlay button now opens the file picker straight away (no sub-panel step). A Freeze result is still lifted onto its own layer.
- Timeline track headers got "+" buttons: add video (Video 1), overlay (Video 2), text (Text), music (Audio), plus a Cover button that stores the frame under the playhead as the project cover.
- Right panel: the tab row (Video / Audio / Animation / Adjust) never moves any more. Tool headers (Volume, Speed, Adjust ... with Cancel / X) sit UNDER the tabs; panels open scrolled to the top; every panel uses the same layout.

v111 (design + polish, on top of v110 keyframe fixes)
- Whole UI re-coloured from navy-blue to CapCut-style graphite/black with a teal-cyan accent (buttons, sliders, tabs, selection).
- Phone layout: the Edit panel no longer opens on its own and covers the timeline or the Add sheets (Text / Media / Effects). It only opens from Edit / tool buttons; the timeline stays visible above it.
- Flat inputs, thin sliders with round white thumbs, white selection ring on clips, white playhead, thin dark scrollbars, press feedback on every button.
- Speed: off-screen tiles/sections skip layout and paint work.

v112 (colours)
- Whole app now uses the same neutral dark greys as Claude's dark theme (background #191919, panels #1f1f1f / #252525, raised #2a2a2a) instead of navy-blue.
- Light blue / cyan accent replaced by a slightly darker blue (Export, Import, sliders, tabs, selection, playhead dot).

v113 — Darker theme (all dark greys ~38% darker), one standard accent (#2f6fdc) for selection borders and every handle
(clip trim, text/overlay/audio handles); timeline head/filmstrip rebuild throttled (rAF + skip unchanged) to cut lag.

v114 — Overlay button: no sub-panel (file picker only). +40 text animations (In/Out): Whip Pan, Light Speed, Zoom Whirl, Barn Door,
Elastic Drop, Hinge Fall, Roll In, Vortex, Neon Boot, Bokeh Blur, Ghost Rise, Snap Zoom, Cinematic Push, Slingshot, Domino, Punch In,
Warp Speed, Soft Rise, Wipe Reveal, Telegraph, Wave Rider, Pendulum Drop, Squash Land, Unfold, Drift, Glitch Slice, Spin Stop, Tilt Shift,
Heartbeat In + letter-by-letter: Bounce Letters, Letter Whip/Roll/Elastic/Ghost/Typhoon/Stomp/Domino/Glitch/Spiral/Tilt. Text glyph buttons -> SVG line icons.

v115 — CapCut-mobile look for phones (<=700px, "Mobile" layout): black UI, Export pill, play row (time left / play centre / undo-redo-full right),
"+" tile at the end of the main track (opens Media), pinch-zoom on the timeline, bottom bar = Add row when nothing is selected / clip tool row when
something is selected (« button returns), CapCut-style bottom sheets. Desktop layout unchanged.

v116 — CapCut mobile pass 2: header X + search + quality chip + cyan Export; play row = fullscreen | play | keyframe | undo | redo
(keyframe is ONE TAP: adds/removes position+scale+rotation+opacity keys at the playhead, no sub panel, removed from the tool bar);
timeline tiles "Mute clip audio" + "Cover"; root bar Edit / Audio / Text / Effects / Overlay / Captions / Filters / Stickers.

v117 — Phone app only: the "Mobile" (stack) layout is forced everywhere; on wide windows the app sits in a centred 480px phone column.
All small-screen CSS now always applies. Sheets close with X, Esc, or by tapping the preview / timeline.

v118 — Tool row: every tool incl. Animation / Adjust / Filters / Effects is a button in ONE swipeable row (no < > arrows, no "..." sub-panel);
the sheet has no tab row (Edit / Volume / Speed / Animation / Adjust are bottom buttons), title follows the tool. Root bar adds Elements + Record.
Removed dev test scripts and reference screenshots from the package.

v119 — Export dialog is a single-column bottom sheet (fits the phone column; preview thumbnail no longer has editor handles baked in).
Tool row gets the missing tools (Speed Curve, Transition, Green Screen, Extract audio, Auto Caption). Both rows can be dragged with the mouse.
Root bar adds AI, Mixer, Multicam, Import, Save, Help (they lived in the old desktop header).

v120: Overlay = direct file picker (no sub panel); duplicate Overlay entry removed from left Import menu; Cover/Mute/Duplicate give toast feedback, Mute applies live; toast class fixed.

v121: preview selection handles no longer jump/shake while scrubbing timeline (per-clip cached video size).

v122: CapCut-style Text flow: Text -> tool row (Add text/Auto Captions/Stickers/Text template); Add text -> sheet with input + check + tabs Templates/Fonts/Styles/Effects/Animations/Bubbles/Presets; Styles sub tabs Text/Stroke/Glow/Background/Shadow/Curve/Spacing/Bold italic.

v123: fixed blank gap above text sheet on wide windows (timeline fixed-position offset), preview now fills space; floating clip bar hidden while text sheet open.

v124: CapCut-style Filters/Adjust: Filters tap -> (Filters|Adjust) row -> sheet tabs Presets/Filters/Adjust/Video quality, check button; Adjust Smart/Customize with icon row + slider + Reset.

v125: CapCut-style preview selection: tap video selects clip (clip tool row), tap empty area deselects (normal row); thin teal outline, no handles; drag moves; two-finger pinch scales+rotates with angle label; finger dot.

v126: Clip tool row grouped like CapCut: top row (Split, Trim, Audio>, Animation, Effects, Delete, Speed>, Transform>, Duplicate, Color>, Cutout>, More>) with sub rows + back; tool panels get bottom title + check bar.

v127 — CapCut-exact tab rows
- Clip row (after tapping the video "handle") is now ONE flat row in CapCut's order: Split, Volume, Animations, Effects, Delete, Speed, Beats, Crop, Duplicate, Overlay, Adjust, Filters, Motion blur, Opacity, Transform, Stabilize, Extract audio, Isolate voice, Reduce noise, Audio effects, Enhance voice, Freeze, Reverse, Mask — then our extras (Cutout, Transition, Auto Caption, Select, Rotate, Mirror, Flip, Trim, Fade, Grade, Edit).
- "More" button and the Audio/Speed/Transform/Color/Cutout group buttons are gone; everything sits directly in the row.
- Root row: Edit, Audio, Text, Effects, Overlay, Captions, Filters, Adjust, Stickers, Aspect ratio (+ Elements, Record, AI, Mixer, Multicam, Import, Save, Help).
- Not in our engine (no button added): Replace, Retouch, Video quality, Remove BG (AI), Relight, Auto reframe, Link, Background.

v128 (on top of NoName-fixed-v2)
- Clip row "Effects" now opens the effects library (169 effects) instead of the Opacity/Blend/Transform props; picking one adds it to the clip and shows its settings.
- Tapping/dragging the preview no longer closes a tool sheet (crop box drag, move, rotate): a drag is not a tap, and tool sheets stay open while a clip is selected.
- Crop > Rotate dial now shows the rotated result live (the crop box hides while rotating; tap an aspect tile to bring the box back).

v129
- Crop is now CapCut-style: the Rotate dial (±45°, labelled ticks) turns the whole frame under the upright crop box; ✓ keeps "rotated frame cropped by the box" (clip.cropRotate, applied in drawContain, so preview and export match). Reset clears it. Transform rotation is separate.
- Junk removal (mechanical, verified): 15 functions nothing calls (old text inspector, join popup, transition helpers…), ~50 CSS selectors / rules whose class or id exists nowhere in HTML/JS, 2 unused @keyframes. About 25 KB. Screenshots of 26 states before vs after were pixel-identical.

v130
- Tool sheets (Animation/Effects, Crop) are shorter, so the preview video box is much bigger while a sheet is open.
- Crop: box + handles always show while the Crop sheet is open (also after rotating and after re-opening); the bottom "Crop ✓" bar now spans the whole phone column on wide windows (it was squeezed/off-screen); ✓ closes the sheet and keeps the crop; closing the sheet any other way ends crop editing.

v131
- CapCut layout for every tool sheet (Animation, Crop, Speed, Volume, Filters, Adjust, Mask…): the timeline (with its side tiles / clip handles) steps aside while the sheet is open, only the play button stays under the video, the video box takes all the space above the sheet. Text and Keyframes sheets still keep the timeline because they need it.

v132: timeline scrollbar/wheel drag shake fixed — the playhead follow loop no longer rewrites scrollLeft while the user is scrolling (tug-of-war). Tested headless only.

v133: selecting text/sticker/overlay no longer auto-opens the sheet (bottom row Edit/Style/Animations/Duplicate/Delete instead; Add text still opens the editor). Preview box for text/sticker/overlay = thin white frame + round buttons: X delete, pencil edit, copy duplicate, corner arrows drag = scale+rotate. Headless-tested only.

v134: new project takes the video's own ratio (portrait = tall preview, CapCut-like) unless you picked one; Media/Text sheets slightly shorter so preview keeps ~same size; left track-head column with the +buttons removed. Headless-tested only.

v135: bottom bars size to content (no empty strip under the tab row), timeline slightly shorter so the preview is taller, Aspect ratio now opens a ratio row (Original/9:16/16:9/1:1/4:5/...). Headless-tested only.

v136: Filters sheet — Intensity is a fixed row at the bottom (not floating over tiles), only the tile grid scrolls, new 'All' tab lists all 63 filters, sheet a bit taller. Headless-tested only.

v137: clip tool row re-ordered (Split, Rotate, Mirror, Flip, Crop, Volume, Speed, Animations, Effects, Filters, Adjust, Delete, Duplicate, ...).

v138: +40 filters (Cinema, Pastel, Sunset, Film, Neon, Winter, Summer, Dreamy, Noir) -> 103 in the All tab; Cutout sheet got a Background tab (Blur/Dim/B&W/Colour/Gradient behind the subject) + 'Keep background' (invert). Tested with a fake segmentation model offline; the real MediaPipe model needs internet and was NOT tested.

v139: Speed > Curve sub-panel rebuilt CapCut-style: Duration old->new, Add/Delete beat, big 0.1x-10x graph with draggable nodes + "Speed N.Nx" label + playhead, Make it smoother (smooth interpolation), presets incl. Flash Out, Reset | name | tick. Headless-tested only.
v139b: Speed Curve sheet is compact - no title bar/tab row/bottom tool row; Curve|Regular tabs moved into footer; video box grows down to the sheet.
v140: Remove BG button -> row [Auto removal | Custom removal | Chroma key]. Custom removal sheet (Auto remove: Restore/Stroke; Customized cutout: Brush/Quick erase/Erase/Stroke, Brush size, Reset) paints a per-clip removal mask on the preview. Chroma key sheet: Color picker on preview + Intensity/Shadow/Feather edge/Clean up edge. Headless-tested only.
v141: Custom removal now like CapCut (brush = area to KEEP, rest removed; loupe while drawing, eye toggle, Applying toast); Auto removal opens Auto remove sheet (Restore/Stroke); Opacity sheet = single slider + Opacity/tick footer.
v142: Transform button -> row [Rotate | Mirror | Advanced]; Advanced sheet with Position (X/Y) / Zoom / Rotate rulers + Reset | Basic | tick. Opacity bug fixed (clip.opacity was never applied to clips).
v143: startup flash fixed - page stays hidden until the phone layout is applied (desktop layout no longer shows first).

v144 - 30 new audio effects (Audio effects panel, audio clips, recorder): Monster, Demon, Giant, Baby, Elf, Helium, Deep voice, Radio, Walkie, Underwater, Wobble, Stutter, Echo, Double echo, Hall, Room, Stadium, Tunnel, Distortion, Overdrive, Lo-fi, Bitcrush, Retro 8-bit, Vintage, Bell, Dalek, Bee, Whisper, Bass boost, Chorus. (nfChainX in index.html)

v145 - Animation sheet redesigned CapCut-style: tabs + scrolling tile area + fixed footer (Duration slider with 0.6s badge, Easing, actions).
