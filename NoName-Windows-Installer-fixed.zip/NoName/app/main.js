const { app, BrowserWindow, shell, session, Menu, dialog, ipcMain, safeStorage } = require('electron');
const { spawn } = require('child_process');
const fs = require('fs');
const os = require('os');
const path = require('path');
app.commandLine.appendSwitch('autoplay-policy', 'no-user-gesture-required');
app.commandLine.appendSwitch('enable-features', 'VaapiVideoDecoder,CanvasOopRasterization');
app.commandLine.appendSwitch('force_high_performance_gpu');
app.commandLine.appendSwitch('disable-features', 'CalculateNativeWinOcclusion');
app.commandLine.appendSwitch('enable-accelerated-video-decode');
app.commandLine.appendSwitch('ignore-gpu-blocklist');
app.commandLine.appendSwitch('enable-gpu-rasterization');
// NOTE: frame-rate limit + vsync stay ON — uncapping them made the page redraw hundreds of times a second and saturate the GPU.
app.commandLine.appendSwitch('enable-zero-copy');
app.commandLine.appendSwitch('enable-native-gpu-memory-buffers');
app.commandLine.appendSwitch('disable-renderer-backgrounding');

// ---- offline text-to-speech with the voices installed on this computer (Windows SAPI / macOS say) ----
function runProc(cmd, args, env) {
  return new Promise((resolve, reject) => {
    let out = '', err = '';
    let p; try { p = spawn(cmd, args, { env: Object.assign({}, process.env, env || {}), windowsHide: true }); } catch (e) { return reject(e); }
    p.stdout.on('data', (d) => { out += d; }); p.stderr.on('data', (d) => { err += d; });
    p.on('error', reject); p.on('close', (c) => (c === 0 ? resolve(out) : reject(new Error(err.trim() || ('exit ' + c)))));
  });
}
ipcMain.handle('nf:voices', async () => {
  try {
    if (process.platform === 'win32') {
      const o = await runProc('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', 'Add-Type -AssemblyName System.Speech; (New-Object System.Speech.Synthesis.SpeechSynthesizer).GetInstalledVoices() | ForEach-Object { $_.VoiceInfo.Name }']);
      return o.split(/\r?\n/).map((x) => x.trim()).filter(Boolean);
    }
    if (process.platform === 'darwin') {
      const o = await runProc('say', ['-v', '?']);
      return o.split(/\r?\n/).map((l) => { const m = l.match(/^(.+?)\s{2,}[a-z]{2,3}[_-]/i); return m ? m[1].trim() : ''; }).filter(Boolean);
    }
  } catch (_) {}
  return [];
});
ipcMain.handle('nf:tts', async (e, a) => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'noname-tts-'));
  const inF = path.join(dir, 'in.txt'), outF = path.join(dir, 'out.wav');
  try {
    const text = String((a && a.text) || '').slice(0, 5000); if (!text.trim()) return { ok: false, error: 'No text.' };
    fs.writeFileSync(inF, text, 'utf8');
    const voice = String((a && a.voice) || ''), rate = Math.max(-10, Math.min(10, Math.round(Number(a && a.rate) || 0)));
    if (process.platform === 'win32') {
      await runProc('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command',
        'Add-Type -AssemblyName System.Speech; $s = New-Object System.Speech.Synthesis.SpeechSynthesizer; if ($env:NFVOICE) { try { $s.SelectVoice($env:NFVOICE) } catch {} }; $s.Rate = [int]$env:NFRATE; $s.SetOutputToWaveFile($env:NFOUT); $s.Speak([IO.File]::ReadAllText($env:NFIN, [Text.Encoding]::UTF8)); $s.Dispose()'],
        { NFVOICE: voice, NFRATE: String(rate), NFIN: inF, NFOUT: outF });
    } else if (process.platform === 'darwin') {
      const args = []; if (voice) args.push('-v', voice); args.push('-r', String(175 + rate * 14), '-o', outF, '--data-format=LEI16@22050', '-f', inF);
      await runProc('say', args);
    } else {
      await runProc('espeak-ng', ['-s', String(160 + rate * 12), '-w', outF, '-f', inF].concat(voice ? ['-v', voice] : []));
    }
    return { ok: true, bytes: fs.readFileSync(outF), mime: 'audio/wav' };
  } catch (err) {
    return { ok: false, error: String((err && err.message) || err) };
  } finally {
    try { fs.rmSync(dir, { recursive: true, force: true }); } catch (_) {}
  }
});
// ---- export engine: real FFmpeg (hardware H.264 when available) ----
// Gemini API key: stored encrypted with the operating-system login (Windows DPAPI / macOS Keychain), never inside the app files
const KEYF = () => path.join(app.getPath('userData'), 'gemini.key');
ipcMain.handle('nf:key:get', async () => { try { const b = fs.readFileSync(KEYF()); return safeStorage.isEncryptionAvailable() ? safeStorage.decryptString(b) : ''; } catch (_) { return ''; } });
ipcMain.handle('nf:key:set', async (e, k) => { try { k = String(k || '').trim(); if (!k) { fs.rmSync(KEYF(), { force: true }); return true; } if (!safeStorage.isEncryptionAvailable()) return false; fs.writeFileSync(KEYF(), safeStorage.encryptString(k)); return true; } catch (_) { return false; } });
const engine = require('./engine.js');
const FF = engine.findFfmpeg(process.resourcesPath);
const exports_ = new Map();                       // id -> { file, fd }
ipcMain.handle('nf:ff:info', async () => { try { return await engine.detect(FF); } catch (e) { return { ok: false, error: String(e) }; } });
ipcMain.handle('nf:ff:begin', async () => {
  const id = String(Date.now()) + Math.random().toString(16).slice(2, 6);
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'noname-exp-')), file = path.join(dir, 'in.webm');
  exports_.set(id, { dir, file, fd: fs.openSync(file, 'w') }); return id;
});
ipcMain.handle('nf:ff:chunk', async (e, id, bytes) => { const x = exports_.get(id); if (!x) return false; fs.writeSync(x.fd, Buffer.from(bytes)); return true; });
ipcMain.handle('nf:ff:cancel', async (e, id) => { const x = exports_.get(id); if (x) { try { fs.closeSync(x.fd); } catch (_) {} try { fs.rmSync(x.dir, { recursive: true, force: true }); } catch (_) {} exports_.delete(id); } return true; });
ipcMain.handle('nf:ff:finish', async (e, id, o) => {
  const x = exports_.get(id); if (!x) return { ok: false, error: 'Export session lost.' };
  try { fs.closeSync(x.fd); } catch (_) {}
  try {
    o = o || {};
    const def = path.join(app.getPath('videos'), String(o.name || 'noname-export.mp4').replace(/[\\/:*?"<>|]+/g, '_'));
    const pick = await dialog.showSaveDialog(win, { title: 'Save video', defaultPath: def, filters: [{ name: 'MP4 video', extensions: ['mp4'] }] });
    if (pick.canceled || !pick.filePath) return { ok: false, canceled: true };
    const r = await engine.transcode(FF, x.file, { output: pick.filePath, fps: o.fps, durationSec: o.durationSec, quality: o.quality, onProgress: (p) => { try { e.sender.send('nf:ff:progress', p); } catch (_) {} } });
    return r;
  } catch (err) { return { ok: false, error: String((err && err.message) || err) }; }
  finally { try { fs.rmSync(x.dir, { recursive: true, force: true }); } catch (_) {} exports_.delete(id); }
});
ipcMain.handle('nf:ff:reveal', async (e, p) => { try { shell.showItemInFolder(String(p)); } catch (_) {} return true; });
if (!app.requestSingleInstanceLock()) { app.quit(); }
let win;
function create() {
  win = new BrowserWindow({
    width: 1480, height: 900, minWidth: 1100, minHeight: 680, show: false,
    backgroundColor: '#0a1020', title: 'No Name', autoHideMenuBar: true,
    icon: path.join(__dirname, process.platform === 'win32' ? 'icon.ico' : 'icons/icon-512.png'),
    webPreferences: { backgroundThrottling: false, spellcheck: false, contextIsolation: true, sandbox: true, preload: path.join(__dirname, 'preload.js') }
  });
  win.once('ready-to-show', () => { win.show(); win.maximize(); });
  win.loadFile(path.join(__dirname, 'index.html'));
  win.webContents.setWindowOpenHandler(({ url }) => { if (/^https?:/.test(url)) shell.openExternal(url); return { action: 'deny' }; });
  win.webContents.on('will-navigate', (e, url) => { if (!url.startsWith('file:')) { e.preventDefault(); if (/^https?:/.test(url)) shell.openExternal(url); } });
  win.webContents.session.on('will-download', (e, item) => { /* native Save dialog is shown by Electron */ });
  win.webContents.on('render-process-gone', () => { try { win.reload(); } catch (_) {} });
  win.on('unresponsive', () => { /* keep waiting; export can block the UI */ });
  win.on('page-title-updated', (e) => e.preventDefault());
}
app.whenReady().then(() => {
  /* Only what the editor really uses (voice-over mic, fullscreen preview, copy/paste, choosing the export folder), and only for the app's own
     file:// page. Anything else (location, notifications, USB, ...) is refused, and so is any other origin. */
  const NF_ALLOWED = new Set(['media', 'audioCapture', 'videoCapture', 'fullscreen', 'clipboard-sanitized-write', 'clipboard-read', 'fileSystem']);
  const nfOwn = (u) => !u || String(u).startsWith('file:');
  session.defaultSession.setPermissionRequestHandler((wc, perm, cb, details) => cb(NF_ALLOWED.has(perm) && nfOwn((details && details.requestingUrl) || (wc && wc.getURL && wc.getURL()))));
  session.defaultSession.setPermissionCheckHandler((wc, perm, origin, details) => NF_ALLOWED.has(perm) && nfOwn(origin || (details && details.requestingUrl)));
  const tpl = [
    { label: 'File', submenu: [{ role: 'quit' }] },
    { label: 'Edit', submenu: [{ role: 'undo' }, { role: 'redo' }, { type: 'separator' }, { role: 'cut' }, { role: 'copy' }, { role: 'paste' }, { role: 'selectAll' }] },
    { label: 'View', submenu: [{ role: 'togglefullscreen' }, { role: 'reload' }] }
  ];
  if (process.platform === 'darwin') tpl.unshift({ label: 'No Name', submenu: [{ role: 'about' }, { type: 'separator' }, { role: 'quit' }] });
  Menu.setApplicationMenu(Menu.buildFromTemplate(tpl));
  create();
  app.on('activate', () => { if (!BrowserWindow.getAllWindows().length) create(); });
});
app.on('second-instance', () => { if (win) { if (win.isMinimized()) win.restore(); win.focus(); } });
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
