# No Name — Android + iOS (Capacitor)

Same `index.html` UI, wrapped as a real app for both phones. NOT built or tested yet (no Android SDK / Xcode where this was prepared).

## Android (Windows or Mac)
1. Install Node.js and Android Studio.
2. In this folder: `npm install` then `npm run add:android`
3. `npm run open:android` -> Run on a phone or emulator.
4. After changing `../app/index.html`: `npm run sync`

## iOS (Mac with Xcode only — Apple does not allow iOS builds on Windows)
1. `npm install` then `npm run add:ios`
2. `npm run open:ios` -> Run on iPhone / simulator.

## Known limits (honest)
- Phone WebView does not have the Electron/FFmpeg export (`engine.js`); export there uses the browser path (MediaRecorder).
- Real "CapCut-level" speed needs a native plugin (Android MediaCodec + iOS AVFoundation/Metal) for decode, effects and export.
  That plugin is not written yet. Build/run the app first, measure with the F3 performance HUD, then we add the plugin where it lags.


## Easiest ways to get an APK (no Android Studio)
**A. GitHub builds it for you.** Put the whole `NoName` folder in a GitHub repo -> Actions tab -> "Build Android APK" -> Run workflow -> download `NoName-debug-apk` (app-debug.apk) -> install on the phone (allow "install unknown apps").
**B. PWA -> APK with PWABuilder.** Deploy `app/` to Netlify (https), open https://www.pwabuilder.com, paste the site URL, choose Android package, download. Needs the site to be installable (manifest + service worker are included).
**C. Just install the PWA.** Open the Netlify URL in Chrome on the phone -> menu -> "Install app" / "Add to Home screen". Opens full screen, works offline after the first load.
The debug APK is for testing; a Play Store release needs a signing key (Android Studio or `gradlew bundleRelease` with a keystore).
