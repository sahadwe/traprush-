// Copies the editor's web files (../app) into ./www so Capacitor can wrap them. Electron-only files are skipped.
const fs = require('fs'), path = require('path');
const src = path.join(__dirname, '..', 'app'), dst = path.join(__dirname, 'www');
const skip = new Set(['main.js', 'preload.js', 'engine.js', 'package.json', 'icon.icns', 'icon.ico', 'sw.js', 'index_dbg.html']);
fs.rmSync(dst, { recursive: true, force: true }); fs.mkdirSync(dst, { recursive: true });
(function copy(a, b) {
  for (const n of fs.readdirSync(a)) {
    if (skip.has(n) && a === src) continue;
    const s = path.join(a, n), d = path.join(b, n);
    if (fs.statSync(s).isDirectory()) { fs.mkdirSync(d, { recursive: true }); copy(s, d); } else fs.copyFileSync(s, d);
  }
})(src, dst);
console.log('www ready:', fs.readdirSync(dst).join(', '));
